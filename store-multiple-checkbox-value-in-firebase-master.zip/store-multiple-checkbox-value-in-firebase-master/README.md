# store-multiple-checkbox-value-in-firebase
store multiple checkbox value in firebase database
