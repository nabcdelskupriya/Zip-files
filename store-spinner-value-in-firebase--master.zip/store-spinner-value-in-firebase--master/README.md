# store-spinner-value-in-firebase-
store spinner value in firebase realtime database with auto increment
