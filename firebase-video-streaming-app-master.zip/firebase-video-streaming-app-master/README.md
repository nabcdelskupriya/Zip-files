# videoStreamingFirebase
here I will show you how you can make a firebase video streaming app using exoplayer 
