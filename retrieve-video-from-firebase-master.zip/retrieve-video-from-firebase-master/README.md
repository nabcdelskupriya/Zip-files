# retrieve-video-from-firebase
retrieve videos from firebase using exoplayer in recyclerview
