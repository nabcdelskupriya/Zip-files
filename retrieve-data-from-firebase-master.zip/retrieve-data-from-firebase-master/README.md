# retrieve-data-from-firebase
here i will show you how you can retrieve data from firebase in recyclerview using firebase recycler adaptor
