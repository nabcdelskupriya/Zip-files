# insert-and-delete-data-from-firebase
insert multiple data in firebase realtime database and delete on Long click
